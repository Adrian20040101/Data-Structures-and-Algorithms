#pragma once

void testAll();