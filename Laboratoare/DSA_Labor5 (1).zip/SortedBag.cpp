#include "SortedBag.h"
#include "SortedBagIterator.h"

//functie suplimentara - intersectia a doua containere

/**this is the constructor. It initializes the root and the relation.
   Time Complexity: Best Case: θ(1)
                    Average Case: θ(1)
                    Worst Case: θ(1)
   **/
SortedBag::SortedBag(Relation r) {
    root = nullptr;
    this->r = r;
}

/**this is the add method. It iterates through the tree and finds the place to insert an element using a given relation
   Time Complexity: Best Case: θ(1), when the tree is empty. It simply sets the new node as the root
                    Average Case: θ(log n), average time complexity of the add method in binary search trees
                    Worst Case: θ(n), when the tree is highly unbalanced, essentially when it is a linked list and we need to add the element at the end
   **/
void SortedBag::add(TComp e) {
    Node* newNode = new Node{ nullptr, nullptr, e };
    if (root == nullptr) {
        root = newNode;
        return;
    }
    Node* current = root;
    while (current != nullptr) {
        if (r(current->value, e)) {
            if (current->right == nullptr) {
                current->right = newNode;
                return;
            }
            current = current->right;
        } else {
            if (current->left == nullptr) {
                current->left = newNode;
                return;
            }
            current = current->left;
        }
    }
}

/**this is the remove method. It uses a recursive approach to remove an element from the tree based on three different scenarios.
   1. When the node to be removed is a leaf, then we can simply remove it
   2. When the node to be removed has got one child (either the left or the right one). In this case we need to assign the child to the current node before deleting it
   3. When the node to be removed has 2 children. We use a separate method that determines the minimum of the right subtree and assign the value of the minimum to the node.
      Now we have a copy of the successor (minimum in the right subtree). Then we need to recursively call the remove method on the node with the minimum value so that
      we effectively "move" the node to be deleted until it becomes a leaf or only has one child.
   Time Complexity: Best Case: θ(1), when the node to be removed is the root and the root has 0 children or 1 child
                    Average Case: θ(log n), average time complexity of the remove method in binary search trees
                    Worst Case: θ(n), when the tree is highly unbalanced, essentially when it is a linked list and we need to remove the element from the end
   **/
bool SortedBag::remove(TComp e) {
    return removeHelper(root, e);
}

bool SortedBag::removeHelper(Node* &node, TComp elem) {
    //Node* &node. This notation allows to modify the node pointer itself, without creating a copy of it, because we need to work with the original node pointer that has been
    // passed as an argument
    if (node == nullptr) {
        return false; //node to be removed is not found
    } else if (node->value > elem) {
        return removeHelper(node->left, elem);
    } else if (node->value < elem) {
        return removeHelper(node->right, elem);
    } else {   //the node has been found
        //Case 1
        if (node->left == nullptr && node->right == nullptr) {
            delete node;
            node = nullptr;
        } else if (node->left == nullptr) {
            //Case 2
            Node* rightChild = node->right;
            delete node;
            node = rightChild;
        } else if (node->right == nullptr) {
            Node* leftChild = node->left;
            delete node;
            node = leftChild;
        } else {
            //Case 3
            Node* min = minimum(node->right);
            node->value = min->value;
            return removeHelper(node->right, min->value);
        }
        return true;
    }
}

/**this is a helper method to identify the minimum in the right subtree
   Time Complexity: Best Case: θ(1), when there is no left node in the right subtree
                    Average Case: θ(log n)
                    Worst Case: θ(n), when there are only left nodes in the right subtree
   **/
Node* SortedBag::minimum(Node* node) {
    if (node == nullptr) {
        return nullptr;
    }else {
        while (node->left != nullptr) {
            node = node->left;
        }
    }
    return node;
}

/**this is the search method. Returns true if it has found a given element, false otherwise
   Time Complexity: Best Case: θ(1), when the searched element is the root
                    Average Case: θ(log n)
                    Worst Case: θ(n), when the tree is highly unbalanced and the node searched is positioned at the end
   **/
bool SortedBag::search(TComp elem) const {
      Node* current = root;
      bool found = false;
      while (current != nullptr && !found){
          if (current->value == elem){
              found = true;
          }else if (r(current->value, elem)){
              current = current->right;
          }else{
              current = current->left;
          }
      }
      if (found)
          return true;
      return false;
}

/**this method counts the number of occurrences of an element in the bag. It uses a recursive approach to find matching values because they can be found in the left/right subtree
   Time Complexity: Best Case: θ(n)
                    Average Case: θ(n)
                    Worst Case: θ(n)
   It always has to iterate through the whole tree to find matching values
   **/
int SortedBag::nrOccurrences(TComp e) const {
    return countOccurrences(root, e);
}

int SortedBag::countOccurrences(Node* node, TComp e) const {
    if (node == nullptr) {
        return 0;  //element is not found
    }

    if (node->value == e) {
        return 1 + countOccurrences(node->left, e) + countOccurrences(node->right, e);
    } else if (r(node->value, e)) {
        return countOccurrences(node->right, e);
    } else {
        return countOccurrences(node->left, e);
    }
}

/**this method returns the size of the tree. It uses a helper method that recursively goes through all the nodes and counts them (no stack needed)
   Time Complexity: Best Case: θ(n)
                    Average Case: θ(n)
                    Worst Case: θ(n)
   **/
int SortedBag::size() const {
    return countNode(root);
}

int SortedBag::countNode(Node* node) const{
    if (node == nullptr) {
        return 0;
    }
    return 1 + countNode(node->left) + countNode(node->right);
}

/**this method returns true if the tree is empty and false otherwise
   Time Complexity: Best Case: θ(1)
                    Average Case: θ(1)
                    Worst Case: θ(1)
   **/
bool SortedBag::isEmpty() const {
	if (size() == 0)
        return true;
    return false;
}


SortedBagIterator SortedBag::iterator() const {
	return SortedBagIterator(*this);
}

/**this is the destructor. It uses a helper method that recursively goes through the nodes and deletes them, starting from the leaves
   Time Complexity: Best Case: θ(n)
                    Average Case: θ(n)
                    Worst Case: θ(n)
   **/
SortedBag::~SortedBag() {
    destroyTree(root);
}

void SortedBag::destroyTree(Node* node) {
    if (node != nullptr) {
        destroyTree(node->left);
        destroyTree(node->right);
        delete node;
    }
}


/**pre: b1 e Bag, b2 e Bag
   post: b3 e Bag, b3 = b1 U b2
   descr: intersects two bags
   Pseudocode:
   function intersectionBag:
      node1 = bag1.root
      node2 = bag2.root
      stack1 = Node(bag1.size)
      top1 : Integer
      stack2 = Node(bag2.size)
      top2 : Integer
      while node1 != nullptr && node2 != nullptr
        while node1 != nullptr
            stack1[++top1] = *node1
            if node1->right != nullptr
                node1 = node1->right
                while node1->left != nullptr
                    stack1[++top1] = *node1
                    node1 = node1->left
                end-while
            end-if
            else
                node1 = nullptr
            end-if
        end-while


   Time Complexity: Best Case: θ(1), when both bags are empty
                    Average Case: θ(n+m), where n is the size of one bag, and m the size of the other bag
                    Worst Case: θ(n+m)
   **/
SortedBag SortedBag::intersectionBag(const SortedBag& bag1, const SortedBag& bag2) {
    SortedBag intersectionBag(bag1.r);

    Node* node1 = bag1.root;
    Node* node2 = bag2.root;

    Node* stack1 = new Node[bag1.size()];
    int top1 = -1;
    Node* stack2 = new Node[bag2.size()];
    int top2 = -1;

    //traverse both bags simultanesly until one of them is empty
    while (node1 != nullptr && node2 != nullptr) {
        //push all nodes from the furst bag onto the stack
        while (node1 != nullptr) {
            stack1[++top1] = *node1;
            if (node1->right != nullptr) {
                node1 = node1->right;
                while (node1->left != nullptr) {
                    stack1[++top1] = *node1;
                    node1 = node1->left;
                }
            }
            else {
                node1 = nullptr;
            }
        }
        //push all nodes from the second bag onto the stack
        while (node2 != nullptr) {
            stack2[++top2] = *node2;
            if (node2->right != nullptr) {
                node2 = node1->right;
                while (node2->left != nullptr) {
                    stack2[++top2] = *node2;
                    node2 = node2->left;
                }
            }
            else {
                node2 = nullptr;
            }
        }

        //if either stack is empty, there are no more elements to compare
        if (top1 == -1 || top2 == -1)
            break;

        //adding elements based on a given relation
        if (top1 >= 0 && (top2 == -1 || stack1[top1].value <= stack2[top2].value)) {
            //add process
            while (node1 != nullptr) {
                if (r(node1->value, stack1[top1].value)) {
                    if (node1->right == nullptr) {
                        node1->right = &stack1[top1];
                        break;
                    }
                    node1 = node1->right;
                } else {
                    if (node1->left == nullptr) {
                        node1->left = &stack1[top1];
                        break;
                    }
                    node1 = node1->left;
                }
            }
            node1 = stack1[--top1].right;  //because we have to traverse so that we keep the sorted order
        } else if (top2 >= 0){
            //add process
            while (node2 != nullptr) {
                if (r(node2->value, stack2[top2].value)) {
                    if (node2->right == nullptr) {
                        node2->right = &stack2[top2];
                        break;
                    }
                    node2 = node2->right;
                } else {
                    if (node2->left == nullptr) {
                        node2->left = &stack2[top2];
                        break;
                    }
                    node2 = node2->left;
                }
            }
            node2 = stack2[--top2].right;
        }
    }

    delete[] stack1;
    delete[] stack2;

    return intersectionBag;
}