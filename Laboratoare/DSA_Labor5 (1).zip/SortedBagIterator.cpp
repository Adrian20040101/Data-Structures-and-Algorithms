#include "SortedBagIterator.h"
#include "SortedBag.h"
#include <exception>

using namespace std;

/**this is the iterator constructor. It initializes the stack used to store the nodes in order, the top index and the current node
   Time Complexity: Best Case: θ(n)
                    Average Case: θ(n)
                    Worst Case: θ(n)
   It has a time complexity of θ(n) because it calls the first() method, which calls the traversal method, which has a time complexity of θ(n)
   **/
SortedBagIterator::SortedBagIterator(const SortedBag& b) : bag(b) {
    stack = new Node[bag.size()];
    top = -1;
    currentNode = nullptr;
    first();
}

/**this method returns the value of the current element or an exception if the currentNode is not in the stack
   Time Complexity: Best Case: θ(1)
                    Average Case: θ(1)
                    Worst Case: θ(1)
   **/
TComp SortedBagIterator::getCurrent() {
    if (!valid())
        throw std::exception();
    else
        return currentNode->value;
}

/**this method checks if the current node is valid (not null)
   Time Complexity: Best Case: θ(1)
                    Average Case: θ(1)
                    Worst Case: θ(1)
   **/
bool SortedBagIterator::valid() {
    if (currentNode == nullptr)
        return false;
    return true;
}

/**this method checks if there are still elements in the stack. If yes, pop the top element. If not, set the stack as empty. That moves the iterator to the next element in the tree
   Time Complexity: Best Case: θ(1)
                    Average Case: θ(1)
                    Worst Case: θ(1)
   **/
void SortedBagIterator::next() {
    if (!valid()) {
        throw std::exception();
    }
    if (top > 0) {
        currentNode = &stack[--top];
    } else {
        currentNode = nullptr;
        top = -1;
    }
}

/**reinitialize top index, perform the traversal and reset the currentNode
   Time Complexity: Best Case: θ(n)
                    Average Case: θ(n)
                    Worst Case: θ(n)
   It has a time complexity of θ(n) because it calls the traversal method, which has a time complexity of θ(n)
   **/
void SortedBagIterator::first() {
    top = -1;
    inOrderTraversal(bag.root);
    currentNode = nullptr;
    if (top > -1) {
        currentNode = &stack[top]; //get the top element from the stack
    }
}

/**the method traverses the tree in reverse in-order way. This ensures that the nodes are stored in the stack in the desired order
    Time Complexity: Best Case: θ(n)
                     Average Case: θ(n)
                     Worst Case: θ(n)
    **/
void SortedBagIterator::inOrderTraversal(Node* node) {
    if (node == nullptr) {
        return;
    }
    inOrderTraversal(node->right);
    stack[++top] = *node;
    inOrderTraversal(node->left);
}

/**this method destroys the stack
   Time Complexity: Best Case: θ(1)
                    Average Case: θ(1)
                    Worst Case: θ(1)
   **/
SortedBagIterator::~SortedBagIterator() {
    delete[] stack;
}
