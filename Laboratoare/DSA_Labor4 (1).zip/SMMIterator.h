#pragma once

#include "SortedMultiMap.h"


class SMMIterator{
	friend class SortedMultiMap;
private:
	//DO NOT CHANGE THIS PART
	const SortedMultiMap& map;
	SMMIterator(const SortedMultiMap& map);

    Relation relation;
    int capacity;
    int size;
    int key_index;
    int value_index;
    Pair* sortedArray;

public:
	void first();
	void next();
	bool valid() const;
   	TElem getCurrent() const;
    vector<TKey> get_all_keys();
};

