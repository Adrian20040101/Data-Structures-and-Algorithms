#include "SMMIterator.h"
#include "SortedMultiMap.h"
#include <iostream>
#include <vector>
#include <exception>
using namespace std;

//ptr functia suplimentara - multimea tuturor cheilor, fara sa contina duplicate

/**this is the constructor. It initializes the elements that the methods will need to use later on
   Time Complexity: Best Case: θ(n)
                    Worst Case θ(n)
                    Average Case: θ(n)
**/
SortedMultiMap::SortedMultiMap(Relation r) {
    relation = r;
    capacity = 23;
    nrElems = 0;
    elements = new Pair[capacity];
    next = new int[capacity];
    for (int i = 0; i < capacity; i++) {
        elements[i].key = NULL_TVALUE;
        elements[i].valueSize = 0;
        elements[i].valueCapacity = 5;
        elements[i].values = new TValue[elements[i].valueCapacity];
        next[i] = -1;
    }

    firstEmpty = 0;
}

/**this is the hash function. It calculates on what position the pair should be placed in the array
   Time Complexity: Best Case: θ(1)
                    Worst Case θ(1)
                    Average Case: θ(1)
**/
int SortedMultiMap::h(TKey c) const{
    return abs(c) % capacity;
}

/**this method changes the firstEmpty index to point to the first empty slot in the array where pairs can be added
   Time Complexity: Best Case: θ(1), when the next firstEmpty is directly after it
                    Worst Case θ(n), when it has to traverse the whole array to find another empty slot, or when there isn't another empty slot
                    Average Case: θ(n)
**/
void SortedMultiMap::changeFirstEmpty() {
    for (int i = firstEmpty + 1; i < capacity; i++) {
        if (elements[i].key == NULL_TVALUE) {
            firstEmpty = i;
            return;
        }
    }
    firstEmpty = -1;
}


/**this method adds a new pair into the array. It either adds a value to an existing key, or it adds a new <key, array of values> pair in the array.
   Time Complexity: Best Case: θ(1), when the key already exists
                    Worst Case θ(n), when it has to resize and rehash
                    Average Case: θ(1), depends on how well the hash function distributes the elements along the array, minimizing collisions
**/
void SortedMultiMap::add(TKey c, TValue v) {
    int pos = h(c);

    //check if there is a need to resize
    if (nrElems == capacity - 1) {
        resize_and_rehash();
    }

    //check if the key already exists in the array
    while (next[pos] != -1) {
        if (elements[pos].key == c) {
            break;
        }
        pos = next[pos];
    }

    //if yes, then check if the values array needs to be resized, and add the value to the values array
    if (elements[pos].key == c) {
        if (elements[pos].valueSize == elements[pos].valueCapacity - 1) {
            resize_value_array(pos);
        }
        elements[pos].values[elements[pos].valueSize] = v;
        elements[pos].valueSize++;
        nrElems++;
        return;
    }

    //if the key was not found, add the key to the first empty position in the array and update the firstEmpty
    elements[firstEmpty].key = c;
    elements[firstEmpty].values[elements[firstEmpty].valueSize] = v;
    elements[firstEmpty].valueSize++;
    //establish the link to the next position to be able to traverse the elements of the same chain
    next[pos] = firstEmpty;
    next[firstEmpty] = -1;
    changeFirstEmpty();
    nrElems++;
}


/**this method searches for a given key and returns a vector containing all values corresponding to that key
   Time Complexity: Best Case: θ(1), when the key is at the position suggested by the hash function and there is only one value corresponding to that key
                    Worst Case θ(n), when it has to go through the all elements to find the desired key
                    Average Case: θ(1)
**/
vector<TValue> SortedMultiMap::search(TKey c) const {
    vector<TValue> result;
    int pos = h(c);
    while (pos != -1 && elements[pos].key != c) {
        pos = next[pos];
    }
    if (pos != -1 && elements[pos].key == c) {
        for (int i = 0; i < elements[pos].valueSize; i++) {
            result.push_back(elements[pos].values[i]);
        }
    }
    return result;
}

/**this method removes a pair from the array. It either removes only a value associated with an existing key, or it removes the whole pair if there are no values left
   Time Complexity: Best Case: θ(1), when the key is at the position suggested by the hash function and after removal, there are no values left
                    Worst Case θ(n), when it has to shift values after a deletion
                    Average Case: θ(1)
**/
bool SortedMultiMap::remove(TKey c, TValue v) {
    //first, check if the array is empty
    if (isEmpty())
        return false;

    //search for the key
    int pos = h(c);
    while (pos != -1 && elements[pos].key != c) {
        pos = next[pos];
    }

    //check if the key has not been found
    if (pos == -1){
        return false;
    }

    //search for the value in the values array
    int valuePos = -1;
    for (int i = 0; i < elements[pos].valueSize; i++) {
        if (elements[pos].values[i] == v) {
            valuePos = i;
            break;
        }
    }

    //check if the value has not been found
    if (valuePos == -1) {
        return false;
    }

    //shift the remaining values to overwrite the removed value
    for (int i = valuePos; i < elements[pos].valueSize - 1; i++) {
        elements[pos].values[i] = elements[pos].values[i + 1];
    }

    elements[pos].valueSize--;
    nrElems--;

    //check if there are still values associated with that key. If yes, then do nothing, else remove the whole pair from the array
    if (elements[pos].valueSize > 0){
        return true;
    }
    else{
        //keep track of the current element in the chain and next one
        int current = pos;
        int nextKey = next[current];

        //copy the values of the next element in the chain
        while (nextKey != -1 && h(elements[nextKey].key) == current) {
            int nextValueSize = elements[nextKey].valueSize;
            int nextValueCapacity = elements[nextKey].valueCapacity;

            delete[] elements[current].values;
            elements[current].values = new TValue[nextValueCapacity];

            //update the element properties
            for (int i = 0; i < nextValueSize; i++) {
                elements[current].values[i] = elements[nextKey].values[i];
            }

            elements[current].key = elements[nextKey].key;
            elements[current].valueSize = nextValueSize;
            elements[current].valueCapacity = nextValueCapacity;

            //update the current and next index to move to the next element in the chain
            current = nextKey;
            nextKey = next[nextKey];
        }

        //remove the last element of the chain and update the position to be set free
        delete[] elements[current].values;
        elements[current].key = NULL_TVALUE;
        elements[current].valueSize = 0;
        elements[current].valueCapacity = 5;
        elements[current].values = new TValue[elements[current].valueCapacity];
        next[current] = -1;

        changeFirstEmpty();
    }
    return true;
}

/**this method returns the number of elements in the array
   Time Complexity: Best Case: θ(1)
                    Worst Case θ(1)
                    Average Case: θ(1)
**/

int SortedMultiMap::size() const {
    return nrElems;
}

/**this method checks if the array is empty
   Time Complexity: Best Case: θ(1)
                    Worst Case θ(1)
                    Average Case: θ(1)
**/
bool SortedMultiMap::isEmpty() const {
    if (nrElems == 0)
        return true;
    return false;
}

SMMIterator SortedMultiMap::iterator() const {
    return SMMIterator(*this);
}

/**this method destroys the each value array corresponding to the keys, elements array and the next array
   Time Complexity: Best Case: θ(1)
                    Worst Case θ(1)
                    Average Case: θ(1)
**/
SortedMultiMap::~SortedMultiMap() {
    for (int i = 0; i < capacity; i++)
        delete[] elements[i].values;
    delete[] elements;
    delete[] next;
}

/**this method resizes and rehashes the array
   Time Complexity: Best Case: θ(n*m), where m is the size of the values array. It is n*m because it always has to copy the pairs and then also each value array for the current key
                    Worst Case θ(n*m)
                    Average Case: θ(n*m)
**/
void SortedMultiMap::resize_and_rehash() {
    int newSize = capacity * 2;
    Pair* newElements = new Pair[newSize];
    int* newNext = new int[newSize];

    //initialize the array for accommodating more pairs
    for (int i = 0; i < newSize; i++) {
        newElements[i].key = NULL_TVALUE;
        newElements[i].valueSize = 0;
        newElements[i].valueCapacity = 5;
        newElements[i].values = new TValue[newElements[i].valueCapacity];
        newNext[i] = -1;
    }

    //distribute the existing elements uniformly throughout the new array by applying the hash function on the existing elements
    for (int i = 0; i < capacity; i++) {
        //only consider non-null elements
        if (elements[i].key != NULL_TVALUE) {
            int pos = abs(elements[i].key) % newSize;
            //if the position is empty, place the element in that position
            if (newElements[pos].key == NULL_TVALUE) {
                newElements[pos].key = elements[i].key;
                newElements[pos].valueSize = elements[i].valueSize;
                newElements[pos].valueCapacity = elements[i].valueCapacity;
                newElements[pos].values = new TValue[elements[i].valueCapacity];
                for (int j = 0; j < elements[i].valueSize; j++) {
                    newElements[pos].values[j] = elements[i].values[j];
                }
            } else {
                int emptySlot = pos;
                //empty slot will represent the last position in the current chain of elements
                while (newNext[emptySlot] != -1) {
                    emptySlot = newNext[emptySlot];
                }

                int nextEmptySlot = emptySlot + 1;

                //find the next available empty position to place the element
                while (newElements[nextEmptySlot].key != NULL_TVALUE) {
                    nextEmptySlot++;
                }

                //link the chain to the new empty spot where the element is going to be placed
                newNext[emptySlot] = nextEmptySlot;

                //copy the element into the empty slot
                newElements[nextEmptySlot] = elements[i];
            }
        }
    }

    //deallocate the memory and update the arrays
    delete[] next;
    next = newNext;
    capacity = newSize;
    delete[] elements;
    elements = newElements;
    changeFirstEmpty();
}

/**this method resizes the value array. It becomes pos as a parameter to identify the position of the pair which values array has to be resized
   Time Complexity: Best Case: θ(n)
                    Worst Case θ(n)
                    Average Case: θ(n)
**/
void SortedMultiMap::resize_value_array(int pos) {
    int newCapacity = elements[pos].valueCapacity * 2;
    TValue* newValues = new TValue[newCapacity];
    //copy the existing values into a new values array
    for (int i = 0; i < elements[pos].valueSize; i++){
        newValues[i] = elements[pos].values[i];
    }
    elements[pos].valueCapacity = newCapacity;
    delete[] elements[pos].values;
    elements[pos].values = newValues;
}

bool SortedMultiMap::duplicate(TKey key){
    int count = 0;
    for (int i = 0; i < capacity; i++) {
        if (elements[i].key == key) {
            count++;
        }
    }
    if (count >= 2)
        return true;
    return false;
}