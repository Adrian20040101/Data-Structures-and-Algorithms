#include "SMMIterator.h"
#include "SortedMultiMap.h"
#include <iostream>

using namespace std;

/**this is the constructor of the iterator. It has to sort the newly created array and initialize the other elements that will be used in implementing the methods in the iterator
   Time Complexity: Best Case: θ(n^2),it has to iterate through the original array and then copy the elements to a temporary element
                    Worst Case θ(n^2)
                    Average Case: θ(n^2)
**/
SMMIterator::SMMIterator(const SortedMultiMap &d) : map(d) {
    relation = map.relation;
    capacity = map.capacity;
    size = 0;
    key_index = 0;
    value_index = 0;
    sortedArray = new Pair[capacity];
    //initialize the array attributes
    for (int i = 0; i < capacity; i++) {
        sortedArray[i].key = NULL_TVALUE;
        sortedArray[i].valueSize = 0;
        sortedArray[i].valueCapacity = 5;
        sortedArray[i].values = new TValue[sortedArray[i].valueCapacity];
    }
    //manual inserting of the elements into the correct position in the array
    //iterate through the original dynamic array
    for (int i = 0; i < map.capacity; i++) {
        if (map.elements[i].key != NULL_TVALUE) {
            //create a temporary element with the values from the original array, making sure the original values remain unchanged
            Pair temp;
            temp.key = map.elements[i].key;
            temp.valueSize = map.elements[i].valueSize;
            temp.valueCapacity = map.elements[i].valueCapacity;
            temp.values = new TValue[temp.valueCapacity];
            for (int j = 0; j < temp.valueSize; j++) {
                temp.values[j] = map.elements[i].values[j];
            }

            //find the correct position in the new array to insert the element
            int position = 0;
            while (position < size && relation(sortedArray[position].key, temp.key)) {
                position++;
            }

            //shift the elements to the right to make space for the new element
            for (int j = size - 1; j >= position; j--) {
                sortedArray[j + 1] = sortedArray[j];
            }

            //insert the element at the correct position
            sortedArray[position] = temp;
            size++;
        }
    }
}

/**this method initializes the key and value index with 0
   Time Complexity: Best Case: θ(1)
                    Worst Case θ(1)
                    Average Case: θ(1)
**/
void SMMIterator::first() {
    key_index = 0;
    value_index = 0;
}

/**this method increments either the key or the value index, or throws an exception if one of them isn't valid
   Time Complexity: Best Case: θ(1)
                    Worst Case θ(1)
                    Average Case: θ(1)
**/
void SMMIterator::next() {
    if (!valid()) {
        throw exception();
    } else {
        if (value_index < sortedArray[key_index].valueSize - 1) {
            value_index++;
        } else {
            value_index = 0;
            key_index++;
        }
    }
}

/**this method checks if the key and value index are in bounds
   Time Complexity: Best Case: θ(1)
                    Worst Case θ(1)
                    Average Case: θ(1)
**/
bool SMMIterator::valid() const {
    if ((key_index < 0 || key_index >= size) || (value_index < 0 || value_index >= sortedArray[key_index].valueSize))
        return false;
    return true;
}

/**this method creates a pair that will be returned, representing the current key and value index
   Time Complexity: Best Case: θ(1)
                    Worst Case θ(1)
                    Average Case: θ(1)
**/
TElem SMMIterator::getCurrent() const {
    if (!valid())
        throw exception();
    TElem pair = make_pair(sortedArray[key_index].key, sortedArray[key_index].values[value_index]);
    return pair;
}

/**descr: this method returns the unique keys in the array
   pre: keys e TKey
   post: returns a vector of unique keys
   Time Complexity: Best Case: θ(n), it has to iterate through the entire array to identify the keys that need to be inserted
                    Worst Case θ(n)
                    Average Case: θ(n)

   Pseudocode:
   function get_all_keys:
      keys: vector
      for i = 1, capacity -1, 1 execute
         if sortedArray[i].key != NULL_TVALUE && sortedArray[i].key != sortedArray[i+1].key
            keys.push_back(sortedArray[i].key
         end-if
      end-for
      return keys
end-function
**/
vector<TKey> SMMIterator::get_all_keys() {
    std::vector<TKey> keys;

    for (int i = 0; i < capacity - 1; i++) {
        if (sortedArray[i].key != NULL_TVALUE && sortedArray[i].key != sortedArray[i+1].key) {
            keys.push_back(sortedArray[i].key);
        }
    }
    return keys;
}